# Android Layout Visualizer

[Experiment with Android Layout XML](http://labs.udacity.com/android-visualizer/#/android/sandbox) with this visualizer. This project directly supports Udacity's Intro to Android course, and is open source under the MIT license.

You'll find the code in the gh-pages branch.
